﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            ViewBag.message = "";
            return View();
        }
        [HttpPost]
        public string submit_data(string s1, string s2, string s3, string s4)
        {
          
        string s="";
           
            try
            {
                LoginModelContainer en=new LoginModelContainer();
          Reg_form reg = new Reg_form();
          reg.Name = s1;
          reg.Age = s2;
          reg.Phone_No = s3;
          reg.Emailid = s4;
          en.Reg_form.Add(reg);
          en.SaveChanges();
          s = "Data Inserted successfully";
            }
            catch (Exception e)
            {
                
                s = e.ToString();
            }

            return s;
        }

        [HttpPost]
        public ActionResult Index(Reg_form r)
        {
            if (string.IsNullOrEmpty(r.Name))
            {
                ModelState.AddModelError("Name", "Please enter your name");
            }
            if (string.IsNullOrEmpty(r.Age))
            {
                ModelState.AddModelError("Age", "Please enter your age");
            }
            if (string.IsNullOrEmpty(r.Phone_No))
            {
                ModelState.AddModelError("Phone_No", "Please enter your Phone number");
            }
            if (string.IsNullOrEmpty(r.Emailid))
            {
                ModelState.AddModelError("Emailid", "Please enter your emaildid");
            }
            if (ModelState.IsValid)
            {
                LoginModelContainer en = new LoginModelContainer();
                en.Reg_form.Add(r);
                en.SaveChanges();
                ViewBag.message = "Data inserted successfully";
            }

            
            return View("Index",new Reg_form());
        }
    }
}
